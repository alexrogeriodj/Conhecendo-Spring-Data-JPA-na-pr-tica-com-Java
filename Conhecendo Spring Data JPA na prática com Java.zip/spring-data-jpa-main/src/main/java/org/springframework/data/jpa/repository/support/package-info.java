/**
 * JPA repository implementations.
 */
@org.springframework.lang.NonNullApi
package org.springframework.data.jpa.repository.support;
