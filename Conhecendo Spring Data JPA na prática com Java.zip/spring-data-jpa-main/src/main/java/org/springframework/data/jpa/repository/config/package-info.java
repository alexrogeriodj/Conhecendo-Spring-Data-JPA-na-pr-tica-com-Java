/**
 * Classes for JPA namespace configuration.
 */
@org.springframework.lang.NonNullApi
package org.springframework.data.jpa.repository.config;
